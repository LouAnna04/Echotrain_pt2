using UnityEngine;
using UnityEngine.UI;

public class PathVisualizerold : MonoBehaviour
{
    public Transform[] waypoints;  // Array dei waypoints che definiscono il percorso
    public GameObject waypointIndicatorPrefab;  // Prefab della sfera (indicatore dei waypoint)
    public GameObject endEffector;  // Riferimento all'oggetto end effector (la mano o robot che segue il percorso)
    public Text waypointCounterText;  // Riferimento al testo UI per mostrare il conteggio dei waypoint

    private LineRenderer lineRenderer;
    private bool pathCompleted = false;  // Flag per sapere se il percorso � stato completato
    private int waypointsPassed = 0;  // Conteggio dei waypoint superati
    private GameObject[] waypointIndicators;  // Array degli indicatori istanziati

    public float waypointTolerance = 0.02f;  // Distanza per essere considerato "arrivato" a un waypoint
    public float maxDistanceFromPath = 0.05f;  // Distanza massima dalla linea per cambiare colore
    public float waypointIndicatorMaxScale = 0.03f;  // Scala massima degli indicatori
    public float waypointIndicatorMinScale = 0.02f;  // Scala minima degli indicatori

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = waypoints.Length;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.startColor = Color.black;
        lineRenderer.endColor = Color.black;

        CreateWaypointIndicators();
    }

    void Update()
    {
        if (!pathCompleted)
        {
            CheckPathProgress();
            UpdateLineRenderer();
            UpdateWaypointCounter();
        }
    }

    void CheckPathProgress()
    {
        if (IsAtFinalWaypoint() && waypointsPassed == waypoints.Length)
        {
            CompletePath();
            return;
        }

        float distanceToCurrentWaypoint = Vector3.Distance(endEffector.transform.position, waypoints[waypointsPassed].position);

        if (distanceToCurrentWaypoint < waypointTolerance)
        {
            waypointsPassed++;  // Passa al prossimo waypoint
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            if (waypointsPassed==1)
            {
                UpdateWaypointIndicatorColor(waypointsPassed - 1, Color.white);
            }
            else
            {
                UpdateWaypointIndicatorColor(waypointsPassed - 1, Color.green);
            }
         
        }
        else if (distanceToCurrentWaypoint > maxDistanceFromPath)
        {
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            UpdateWaypointIndicatorColor(waypointsPassed, Color.red);
        }
        else
        {
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            UpdateWaypointIndicatorColor(waypointsPassed, Color.green);
        }
    }

    bool IsAtFinalWaypoint()
    {
        return Vector3.Distance(endEffector.transform.position, waypoints[waypoints.Length - 1].position) < waypointTolerance;
    }

    void CompletePath()
    {
        if (!pathCompleted)
        {
            pathCompleted = true;
            lineRenderer.enabled = false;

            // Rende invisibili i waypoint
            foreach (var indicator in waypointIndicators)
            {
                indicator.SetActive(false);
            }

            Debug.Log("You completed the path successfully");
        }
    }

    void UpdateLineRenderer()
    {
        for (int i = 0; i < waypoints.Length; i++)
        {
            lineRenderer.SetPosition(i, waypoints[i].position);
        }
    }

    void CreateWaypointIndicators()
    {
        waypointIndicators = new GameObject[waypoints.Length];

        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] != null && waypointIndicatorPrefab != null)
            {
                var indicator = Instantiate(waypointIndicatorPrefab, waypoints[i].position, Quaternion.identity);
                indicator.transform.localScale = Vector3.one * waypointIndicatorMaxScale;
                waypointIndicators[i] = indicator;
            }
        }
    }

    void UpdateWaypointIndicatorColor(int index, Color color)
    {
        if (index >= 0 && index < waypointIndicators.Length)
        {
            var renderer = waypointIndicators[index].GetComponent<Renderer>();
            if (renderer != null)
            {
                renderer.material.color = color;
            }
        }
    }

    void UpdateWaypointCounter()
    {
        if (waypointCounterText != null)
        {
            waypointCounterText.text = $"Waypoints Passed: {waypointsPassed}/{waypoints.Length}";
        }
    }
}
