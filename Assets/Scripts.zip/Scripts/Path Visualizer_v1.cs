using UnityEngine;

public class PathVisualizer : MonoBehaviour
{
    public Transform[] waypoints;  // Array dei waypoints che definiscono il percorso
    public GameObject waypointIndicatorPrefab;  // Prefab della sfera (indicatore dei waypoint)
    public GameObject endEffector;  // Riferimento all'oggetto end effector (la mano o robot che segue il percorso)

    private LineRenderer lineRenderer;
    private bool pathCompleted = false;  // Flag per sapere se il percorso � stato completato

    // Distanza massima tollerata per essere considerato "arrivato" a un waypoint
    public float waypointTolerance = 0.5f;

    // Distanza massima consentita dalla linea per cambiare colore a rosso
    public float maxDistanceFromPath = 1.0f;

    void Start()
    {
        // Ottieni il componente LineRenderer
        lineRenderer = GetComponent<LineRenderer>();

        // Impostazioni iniziali del LineRenderer
        lineRenderer.positionCount = waypoints.Length;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.startColor = Color.green;
        lineRenderer.endColor = Color.green;

        // Instanzia gli indicatori dei waypoint
        CreateWaypointIndicators();
    }

    void Update()
    {
        if (!pathCompleted)
        {
            // Controlla se l'utente sta seguendo correttamente il percorso
            CheckPathProgress();

            // Aggiorna la posizione della linea nel LineRenderer
            UpdateLineRenderer();
        }
    }

    void CheckPathProgress()
    {
        // Verifica se l'utente ha completato il percorso
        if (IsAtFinalWaypoint())
        {
            // Se ha raggiunto l'ultimo waypoint, il percorso � completo
            CompletePath();
        }
        else
        {
            // Controlla se l'utente � abbastanza vicino al waypoint corrente
            bool onPath = false;
            for (int i = 0; i < waypoints.Length; i++)
            {
                if (Vector3.Distance(endEffector.transform.position, waypoints[i].position) < waypointTolerance)
                {
                    // Se l'utente � vicino al waypoint, continua
                    onPath = true;
                    // Cambia la linea in verde se � sulla traiettoria
                    lineRenderer.startColor = Color.green;
                    lineRenderer.endColor = Color.green;
                    break;
                }
            }

            // Se l'utente � lontano dal percorso (oltre la distanza massima), la linea diventa rossa
            if (!onPath)
            {
                lineRenderer.startColor = Color.red;
                lineRenderer.endColor = Color.red;
            }
        }
    }

    // Verifica se l'utente � arrivato al waypoint finale
    bool IsAtFinalWaypoint()
    {
        return Vector3.Distance(endEffector.transform.position, waypoints[waypoints.Length - 1].position) < waypointTolerance;
    }

    // Funzione per segnare il completamento del percorso
    void CompletePath()
    {
        if (!pathCompleted)
        {
            pathCompleted = true;
            // Nascondi la linea e i waypoint
            lineRenderer.enabled = false;

            // Nascondi gli indicatori dei waypoint
            foreach (Transform waypoint in waypoints)
            {
                Destroy(waypoint.gameObject);
            }

            // Opzionale: Aggiungi un feedback o azione successiva al completamento (ad esempio, un messaggio)
            Debug.Log("You completed the path successfully");
        }
    }

    // Funzione per aggiornare la Linea con i waypoint
    void UpdateLineRenderer()
    {
        for (int i = 0; i < waypoints.Length; i++)
        {
            lineRenderer.SetPosition(i, waypoints[i].position);
        }
    }

    // Funzione per creare gli indicatori visivi (sfere) sui waypoint
    void CreateWaypointIndicators()
    {
        foreach (var waypoint in waypoints)
        {
            if (waypoint != null && waypointIndicatorPrefab != null)
            {
                // Instanzia il prefab dell'indicatore sulla posizione del waypoint
                Instantiate(waypointIndicatorPrefab, waypoint.position, Quaternion.identity);
            }
        }
    }
}
