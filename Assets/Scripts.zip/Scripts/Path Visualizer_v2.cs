using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PathVisualizerv2 : MonoBehaviour
{
    public Transform[] waypoints;  // Array dei waypoints che definiscono il percorso
    public GameObject waypointIndicatorPrefab;  // Prefab della sfera (indicatore dei waypoint)
    public GameObject endEffector;  // Riferimento all'oggetto end effector (la mano o robot che segue il percorso)
    public Text waypointCounterText;  // Riferimento al testo UI per mostrare il conteggio dei waypoint

    private LineRenderer lineRenderer;
    private bool pathCompleted = false;  // Flag per sapere se il percorso � stato completato
    private int waypointsPassed = 0;  // Conteggio dei waypoint superati
    private GameObject[] waypointIndicators;  // Array degli indicatori istanziati

    public float waypointTolerance = 0.02f;  // Distanza per essere considerato "arrivato" a un waypoint
    public float maxDistanceFromPath = 0.05f;  // Distanza massima dalla linea per cambiare colore
    public float waypointIndicatorMaxScale = 0.03f;  // Scala massima degli indicatori
    public float waypointIndicatorMinScale = 0.02f;  // Scala minima degli indicatori

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        InitializePath();
    }

    // Metodo pubblico per rieseguire l'inizializzazione
    public void ResetPath()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.enabled = true;
        pathCompleted = false;
        waypointsPassed = 0;
        // Rende invisibili i waypoint
        foreach (var indicator in waypointIndicators)
        {
            Destroy(indicator.gameObject);
        }
        InitializePath();
        Debug.Log("PathVisualizerv2 resettato.");
        Update();
    }

    void Update()
    {
        if (!pathCompleted)
        {
            CheckPathProgress();
            UpdateLineRenderer();
            UpdateWaypointCounter();
        }
    }

    void CheckPathProgress()
    {
        if (IsAtFinalWaypoint() && waypointsPassed == waypoints.Length)
        {
            CompletePath();
            return;
        }

        float distanceToCurrentWaypoint = Vector3.Distance(endEffector.transform.position, waypoints[waypointsPassed].position);

        if (distanceToCurrentWaypoint < waypointTolerance)
        {
            waypointsPassed++;  // Passa al prossimo waypoint
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            if (waypointsPassed==1)
            {
                UpdateWaypointIndicatorColor(waypoints.Length - 1, Color.green);
                UpdateWaypointIndicatorColor(waypointsPassed - 1, Color.green);
            }
            else
            {
                UpdateWaypointIndicatorColor(waypointsPassed - 1, Color.green);
                UpdateWaypointIndicatorColor(waypointsPassed - 2, Color.white);
                if (waypointsPassed == 2)
                {
                UpdateWaypointIndicatorColor(waypoints.Length - 1, Color.white);
                }
                if (waypointsPassed == 5)
                {
                    UpdateWaypointIndicatorColor(0, Color.green);
                }
            }
         
        }
        else if (distanceToCurrentWaypoint > maxDistanceFromPath)
        {
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            if (waypointsPassed == 0)
            {
                UpdateWaypointIndicatorColor(waypoints.Length - 1, Color.red);
            }
            if (waypointsPassed == 4)
            {
                UpdateWaypointIndicatorColor(0, Color.red);
            }
            UpdateWaypointIndicatorColor(waypointsPassed, Color.red);
        }
    }

    bool IsAtFinalWaypoint()
    {
        return Vector3.Distance(endEffector.transform.position, waypoints[waypoints.Length - 1].position) < waypointTolerance;
    }

    void CompletePath()
    {
        if (!pathCompleted)
        {
            pathCompleted = true;
            lineRenderer.enabled = false;

            // Rende invisibili i waypoint
            foreach (var indicator in waypointIndicators)
            {
                //indicator.SetActive(false);
                Destroy(indicator.gameObject);

            }

            Debug.Log("You completed the path successfully");
        }
    }

    void UpdateLineRenderer()
    {
        for (int i = 0; i < waypoints.Length; i++)
        {
            lineRenderer.SetPosition(i, waypoints[i].position);
        }
    }

    void CreateWaypointIndicators()
    {
        waypointIndicators = new GameObject[waypoints.Length];

        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] != null && waypointIndicatorPrefab != null)
            {
                var indicator = Instantiate(waypointIndicatorPrefab, waypoints[i].position, Quaternion.identity);
                indicator.transform.localScale = Vector3.one * waypointIndicatorMaxScale;
                waypointIndicators[i] = indicator;
            }
        }
    }

    void UpdateWaypointIndicatorColor(int index, Color color)
    {
        if (index >= 0 && index < waypointIndicators.Length)
        {
            var renderer = waypointIndicators[index].GetComponent<Renderer>();
            if (renderer != null)
            {
                renderer.material.color = color;
            }
        }
    }

    void UpdateWaypointCounter()
    {
        if (waypointCounterText != null)
        {
            waypointCounterText.text = $"Waypoints Passed: {waypointsPassed}/{waypoints.Length}";
        }
    }

    private void InitializePath()
    {
        lineRenderer.positionCount = waypoints.Length;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        
        CreateWaypointIndicators();
    }
}

