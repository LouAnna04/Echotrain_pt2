using UnityEngine;

public class LimitaMovimentoSferico : MonoBehaviour
{
    public Transform padre;      // Riferimento all'oggetto padre
    public float maxDistance = 1.1005f; // Raggio massimo in cui il figlio pu� muoversi

    void Update()
    {
        // Calcola la distanza tra il figlio e il padre
        Vector3 direzione = transform.position - padre.position;

        // Calcola la distanza attuale
        float distanza = direzione.magnitude;

        // Se il figlio � fuori dalla sfera (distanza maggiore del raggio)
        if (distanza > maxDistance)
        {
            // Limita la posizione del figlio mantenendo la stessa direzione ma con distanza massima
            transform.position = padre.position + direzione.normalized * maxDistance;
        }
    }
}
