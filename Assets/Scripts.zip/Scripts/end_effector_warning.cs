using UnityEngine;
using UnityEngine.UI;

public class EndEffectorWarning : MonoBehaviour
{
    public GameObject endEffector;        // Riferimento all'end effector
    public GameObject warningScreen;      // UI con la schermata rossa di avviso
    public GameObject centerObject;       // Punto centrale della sfera
    public float maxRadius = 0.5f;        // Raggio massimo della sfera

    private bool isHandInContact = false; // Stato di contatto tra la mano e l'end effector

    void Start()
    {
        warningScreen.SetActive(false); // Nascondi la schermata di avviso all'inizio
    }

    void Update()
    {
        // Calcola la distanza tra la mano virtuale e il centro della sfera
        Vector3 direzione = endEffector.transform.position - centerObject.transform.position;

        // Calcola la distanza attuale
        float distanza = direzione.magnitude;

        // Se la mano � in contatto e la distanza supera il raggio massimo
        if (distanza > maxRadius)
        {
            ShowWarning();
        }
        else
        {
            HideWarning();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Controlla se la mano virtuale entra in contatto con l'end effector
        if (other.gameObject == endEffector)
        {
            isHandInContact = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        // Controlla se la mano virtuale esce dal contatto con l'end effector
        if (other.gameObject == endEffector)
        {
            isHandInContact = false;
            HideWarning();
        }
    }

    private void ShowWarning()
    {
        warningScreen.SetActive(true); // Mostra la schermata di avviso
    }

    private void HideWarning()
    {
        warningScreen.SetActive(false); // Nascondi la schermata di avviso
    }
}
