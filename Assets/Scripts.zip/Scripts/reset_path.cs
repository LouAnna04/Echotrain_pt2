using UnityEngine;

public class PathVisualizerReloader : MonoBehaviour
{
    public PathVisualizerv2 pathVisualizer;  // Riferimento allo script PathVisualizerv2

    void Update()
    {

    }

    public void ReloadPathVisualizer()
    {
        if (pathVisualizer != null)
        {
            // Disabilita e riabilita lo script per forzare il reset
            pathVisualizer.enabled = false;
            pathVisualizer.enabled = true;

            Debug.Log("PathVisualizerv2 resettato e rieseguito.");
        }
    }
}