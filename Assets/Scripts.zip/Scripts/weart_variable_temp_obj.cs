using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WeArt.Components;
using WeArt.Core;

public class weart_variable_temp_obj : MonoBehaviour
{
    [SerializeField, Range(0f, 1f)]
    private float _volumeTemperature = 0.5f; // Temperatura di riferimento per il volume

    [SerializeField]
    private float _maxDistance = 5f; // Distanza massima per l'interpolazione della temperatura

    private List<TouchableInVolume> touchablesInsideTheVolume = new List<TouchableInVolume>();

    private struct TouchableInVolume
    {
        public WeArtTouchableObject touchableObject;
        public float initialTemperature;
        public bool initialActiveTemperature;
    }

    public float VolumeTemperature
    {
        get { return _volumeTemperature; }
        set { _volumeTemperature = value; }
    }

    void Start()
    {

    }

    void Update()
    {
        // Aggiornamento continuo della temperatura per gli oggetti dentro il volume
        foreach (var touch in touchablesInsideTheVolume)
        {
            if (touch.touchableObject != null)
            {
                UpdateObjectTemperature(touch.touchableObject);
            }
        }
    }

    private void OnDisable()
    {
        ReverseTouchableObjectsToOriginal();
    }

    private void OnDestroy()
    {
        ReverseTouchableObjectsToOriginal();
    }

    private void ReverseTouchableObjectsToOriginal()
    {
        foreach (var touch in touchablesInsideTheVolume)
        {
            if (touch.touchableObject == null)
                continue;

            Temperature temp = touch.touchableObject.Temperature;
            temp.Value = touch.initialTemperature;
            temp.Active = touch.initialActiveTemperature;
            touch.touchableObject.Temperature = temp;
        }
        touchablesInsideTheVolume.Clear();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (TryGetTouchableObjectFromCollider(other, out WeArtTouchableObject touchable))
        {
            bool found = false;
            foreach (var touch in touchablesInsideTheVolume)
            {
                if (touch.touchableObject == touchable)
                    found = true;
            }

            if (!found)
            {
                touchablesInsideTheVolume.Add(new TouchableInVolume
                {
                    touchableObject = touchable,
                    initialTemperature = touchable.Temperature.Value,
                    initialActiveTemperature = touchable.Temperature.Active
                });
                // Impostiamo la temperatura iniziale all'entrata
                UpdateObjectTemperature(touchable);
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (TryGetTouchableObjectFromCollider(other, out WeArtTouchableObject touchable))
        {
            // Aggiorniamo continuamente la temperatura mentre l'oggetto � dentro il volume
            UpdateObjectTemperature(touchable);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (TryGetTouchableObjectFromCollider(other, out WeArtTouchableObject touchable))
        {
            foreach (var touch in touchablesInsideTheVolume)
            {
                if (touch.touchableObject == touchable)
                {
                    Temperature temp = touchable.Temperature;
                    temp.Value = touch.initialTemperature;
                    temp.Active = touch.initialActiveTemperature;
                    touchable.Temperature = temp;
                    touchablesInsideTheVolume.Remove(touch);
                    break;
                }
            }
        }
    }

    private static bool TryGetTouchableObjectFromCollider(Collider collider, out WeArtTouchableObject touchableObject)
    {
        touchableObject = collider.gameObject.GetComponent<WeArtTouchableObject>();
        return touchableObject != null;
    }

    private void UpdateObjectTemperature(WeArtTouchableObject touchableObject)
    {
        // Calcola la distanza dell'oggetto dal centro del volume
        float distance = Vector3.Distance(touchableObject.transform.position, transform.position);

        // Interpoliamo la temperatura in base alla distanza
        // La temperatura diminuisce man mano che ci si allontana dal centro
        float t = Mathf.Clamp01(distance / _maxDistance);  // Interpolazione da 0 a 1
        float newTemperature = Mathf.Lerp(_volumeTemperature, 0f, t);  // Interpolazione tra volumeTemperature e 0

        // Applichiamo la nuova temperatura all'oggetto
        Temperature temp = touchableObject.Temperature;
        temp.Value = newTemperature;
        temp.Active = true; // La temperatura � attiva
        touchableObject.Temperature = temp;
    }
}

